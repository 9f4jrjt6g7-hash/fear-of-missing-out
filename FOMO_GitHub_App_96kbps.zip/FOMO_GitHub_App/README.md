# FEAR OF MISSING OUT

A Home Screen music web app containing the uploaded tracks.

Upload the contents of this folder to the root of a GitHub Pages repository. The `audio` folder must be uploaded too.
